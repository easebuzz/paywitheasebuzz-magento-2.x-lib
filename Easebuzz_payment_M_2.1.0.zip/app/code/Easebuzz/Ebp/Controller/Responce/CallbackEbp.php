<?php

/**
 * @copyright  Easebuzz
 * @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 */

namespace Easebuzz\Ebp\Controller\Responce;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Action\Action as AppAction;

class CallbackEbp extends AppAction {

    /**
     * @var \Easebuzz\Ebp\Model\PaymentMethod
     */
    protected $_paymentMethod;

    /**
     * @var \Magento\Sales\Model\Order
     */
    protected $_order;

    /**
     * @var \Magento\Sales\Model\OrderFactory
     */
    protected $_orderFactory;

    /**
     * @var Magento\Sales\Model\Order\Email\Sender\OrderSender
     */
    protected $_orderSender;

    /**
     * @var \Psr\Log\LoggerInterface
     */
    protected $_logger;
    protected $request;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     * @param \Easebuzz\Ebp\Model\PaymentMethod $paymentMethod
     * @param Magento\Sales\Model\Order\Email\Sender\OrderSender $orderSender
     * @param  \Psr\Log\LoggerInterface $logger
     */
     
    public function __construct(
    \Magento\Framework\App\Action\Context $context, \Magento\Framework\App\Request\Http $request, \Magento\Sales\Model\OrderFactory $orderFactory, \Easebuzz\Ebp\Model\PaymentMethod $paymentMethod, \Magento\Sales\Model\Order\Email\Sender\OrderSender $orderSender, \Psr\Log\LoggerInterface $logger
    ) {
        $this->_paymentMethod = $paymentMethod;
        $this->_orderFactory = $orderFactory;
        $this->_client = $this->_paymentMethod->getClient();
        $this->_orderSender = $orderSender;		
        $this->_logger = $logger;	
		$this->request = $request;
        parent::__construct($context);
    }

    /**
     * Handle POST request to Easebuzz callback endpoint.
     */
    public function execute() {
        try {

            if ($this->request->getPost()) {
                $this->logResponceAction();
                $this->_success();
                $this->paymentAction();
            } else {
                $this->_logger->addError("Easebuzz: no post back data received in callback");
                return $this->_failure();
            }
        } catch (Exception $e) {
            $this->_logger->addError("Easebuzz: error processing callback");
            $this->_logger->addError($e->getMessage());
            return $this->_failure();
        }

        $this->_logger->addInfo("Transaction END from Easebuzz");
    }

    protected function logResponceAction() {

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); // Instance of object manager
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();
        $table = $resource->getTableName('ease_buzz_debug');
        //Update Data into table
        $postdata = $this->getRequest()->getPost();
        $ordid = $postdata['txnid'];

        $sqlUpdate = "UPDATE $table SET response_debug_at = '" . date("YmdHis", time()) . "', response_body = '" . json_encode($postdata) . "'  WHERE order_id = " . $ordid . "";
        $connection->query($sqlUpdate);
        
    }

    protected function paymentAction() {
        $ebkey = $this->_paymentMethod->getConfigData('ebkey');
        $ebsalt = $this->_paymentMethod->getConfigData('ebsalt');

        if ($this->getRequest()->isPost()) {

            $postdata = $this->getRequest()->getPost();

            if (isset($postdata ['key']) && ($postdata['key'] == $ebkey)) {
                $ordid = $postdata['txnid'];
                $this->_loadOrder($ordid);

                $message = '';
                $message .= 'orderId: ' . $ordid . "\n";

                $status = $postdata['status'];
                $udf1 = $postdata['udf1'];
                $udf2 = $postdata['udf2'];
                $udf3 = $postdata['udf3'];
                $udf4 = $postdata['udf4'];
                $udf5 = $postdata['udf5'];
                $email = $postdata['email'];
                $firstname = $postdata['firstname'];
                $productinfo = $postdata['productinfo'];
                $amount = $postdata['amount'];
                $txnid = $postdata['txnid'];
                $key = $postdata['key'];
                $responcehase = $postdata['hash'];


                if (isset($postdata['status']) && $postdata['status'] == 'success') {

                    $responce_info = $ebsalt . '|' . $status . '||||||' . $udf5 . '|' . $udf4 . '|' . $udf3 . '|' . $udf2 . '|' . $udf1 . '|' . $email . '|' . $firstname . '|' . $productinfo . '|' . $amount . '|' . $txnid . '|' . $ebkey;
                    $hase = hash('SHA512', $responce_info);

                    foreach ($postdata as $k => $val) {
                        $message .= $k . ': ' . $val . "\n";
                    }
                    if ($hase == $responcehase) {
                        // success	
                       $this->messageManager->addSuccess("Order Successfully placed. <br/>");
		       $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                       $order = $objectManager->create('\Magento\Sales\Model\Order') ->load($ordid);
                       $order->setState("processing")->setStatus("processing");
                       $order->save();
                       $order->setIsNotified(true);


                        $redirectUrl = $this->_paymentMethod->getSuccessUrl();
                        $this->_redirect($redirectUrl);
                    } else {
                        $this->_createEaseebuzzComment("Easebuzz Response signature does not match. You might have received tampered data", true);
                        $this->_order->cancel()->save();

                        $this->_logger->addError("Easebuzz Response signature did not match ");

                        $this->messageManager->addError("<strong>Error:</strong> Easebuzz Response signature does not match. You might have received tampered data");
                        $this->_redirect('checkout/onepage/failure');
                    }
                } else {
                    
                    $historymessage = $message;

                    $this->_createEaseebuzzComment($historymessage);
                    $this->_order->cancel()->save();

                    $this->messageManager->addError("Order cancelled... <br/>");

                    $redirectUrl = $this->_paymentMethod->getCancelUrl();
                    $this->_redirect($redirectUrl);
                }
            }
        }
    }

    
    protected function _loadOrder($order_id) {
        $this->_order = $this->_orderFactory->create()->loadByIncrementId($order_id);

        if (!$this->_order && $this->_order->getId()) {
            throw new Exception('Could not find Magento order with id $order_id');
        }
    }

    protected function _success() {
        $this->getResponse()
                ->setStatusHeader(200);
    }

    protected function _failure() {
        $this->getResponse()
                ->setStatusHeader(400);
    }

    /**
     * Returns the generated comment or order status history object.
     *
     * @return string|\Magento\Sales\Model\Order\Status\History
     */
    protected function _createEaseebuzzComment($message = '') {
        if ($message != '') {
            $message = $this->_order->addStatusHistoryComment($message);
            $message->setIsCustomerNotified(null);
        }

        return $message;
    }

}
